// assets/script.js
// Adds simple client-side validation hints (non-essential)
document.addEventListener('submit', function(e){
  // no-op, server does validation
});
