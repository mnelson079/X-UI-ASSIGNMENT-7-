<?php
// mock success: create or find a user, then log them in
require 'db.php';

$name = 'google_user_' . rand(1000,9999);
$email = 'google.' . rand(1000,9999) . '@example.com';

// try to find a user with this email
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();
if (!$user) {
    // create user with random password
    $hash = password_hash(bin2hex(random_bytes(6)), PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username,email,password) VALUES (?,?,?)");
    $stmt->execute([$name,$email,$hash]);
    $id = $pdo->lastInsertId();
    $_SESSION['user'] = ['id'=>$id,'username'=>$name,'email'=>$email];
} else {
    $_SESSION['user'] = ['id'=>$user['id'],'username'=>$user['username'],'email'=>$user['email']];
}
header('Location: dashboard.php');
exit;
