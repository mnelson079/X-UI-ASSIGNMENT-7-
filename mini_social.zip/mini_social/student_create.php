<?php
require 'db.php';
if (!isset($_SESSION['user'])) { header('Location:index.php'); exit;}
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    if ($student_id === '' || $name === '') $errors[] = 'Student ID and Name required.';
    if (!$errors) {
        $stmt = $pdo->prepare("INSERT INTO students (student_id,name,email) VALUES (?,?,?)");
        $stmt->execute([$student_id,$name,$email]);
        header('Location: dashboard.php'); exit;
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add Student</title>
  <link rel="stylesheet" href="assets/style3.css"></head>
<body class="centered">
  <div class="card">
    <h3>Add Student</h3>
    <?php if($errors) foreach($errors as $e) echo "<div class='errors'>$e</div>"; ?>
    <form method="post">
      <input name="student_id" placeholder="Student ID" required>
      <input name="name" placeholder="Name" required>
      <input name="email" placeholder="Email">
      <div>
        <button type="submit" class="btn">Save</button>
        <a href="dashboard.php" class="link">Cancel</a>
      </div>
    </form>
  </div>
</body>
</html>
