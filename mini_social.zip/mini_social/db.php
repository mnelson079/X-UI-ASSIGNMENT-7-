<?php
// db.php - connect to MySQL and start session
$host = 'localhost';
$db   = 'mini_social';
$user = 'root';
$pass = ''; // set your mysql password here
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // If database doesn't exist yet, don't show sensitive info
    echo 'DB connection failed: ' . $e->getMessage();
    exit;
}
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
