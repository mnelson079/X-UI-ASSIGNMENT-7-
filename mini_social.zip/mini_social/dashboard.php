<?php
require 'db.php';
if (!isset($_SESSION['user'])) {
    header('Location: index.php'); exit;
}
$user = $_SESSION['user'];

// fetch students
$stmt = $pdo->query("SELECT * FROM students ORDER BY id ASC");
$students = $stmt->fetchAll();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <header class="topbar">
    <div class="brand">Dashboard</div>
    <div class="user">Welcome, <?=htmlspecialchars($user['username'])?> | <a href="logout.php">Logout</a></div>
  </header>
  <main class="container">
    <section class="card">
      <h3>Students</h3>
      <a href="student_create.php" class="btn">Add Student</a>
      <table class="data">
        <thead><tr><th>ID</th><th>Student ID</th><th>Name</th><th>Email</th><th>Action</th></tr></thead>
        <tbody>
          <?php foreach($students as $s): ?>
          <tr>
          <td><?= $s['id'] ?></td> 
            <td><?= htmlspecialchars($s['student_id']) ?></td>
            <td><?= htmlspecialchars($s['name']) ?></td>
            <td><?= htmlspecialchars($s['email']) ?></td>
            <td>
              <a href="student_edit.php?id=<?= $s['id'] ?>" class="link">Edit</a> |
              <a href="student_delete.php?id=<?= $s['id'] ?>" onclick="return confirm('Delete?')" class="link">Delete</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </section>
  </main>
<script src="assets/script.js"></script>
</body>
</html>
