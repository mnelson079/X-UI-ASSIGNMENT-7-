<?php
// Run this file once (via browser or CLI) to create an admin user with a chosen password.
// Example: open http://localhost/mini_social/create_admin.php
require 'db.php';
if (php_sapi_name() === 'cli') {
    $pw = $argv[1] ?? '';
    if (!$pw) {
        echo "Usage: php create_admin.php <password>\n";
        exit;
    }
} else {
    $pw = $_GET['pw'] ?? '';
    if (!$pw) {
        echo '<form method="get">Admin password: <input name="pw" /><button>Create</button></form>';
        exit;
    }
}
$username = 'admin';
$email = 'admin@example.com';
//$hash = password_hash($pw, PASSWORD_DEFAULT);
// check if exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
$stmt->execute([$username,$email]);
if ($stmt->fetch()) {
    echo 'Admin user already exists.\n';
    exit;
}
$stmt = $pdo->prepare("INSERT INTO users (username,email,password) VALUES (?,?,?)");
$stmt->execute([$username,$email/*,$hash*/]);
echo 'Admin created (username: admin).\n';
