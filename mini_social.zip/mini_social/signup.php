<?php
require 'db.php';
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($username === '' || $email === '' || $password === '' || $confirm === '') {
        $errors[] = 'All fields are required.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        // check existing
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $errors[] = 'Username or email already taken.';
        } else {
          $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username,email,password) VALUES (?,?,?)");
            $stmt->execute([$username,$email,$hash]);
            // login and redirect
            $_SESSION['user'] = ['username'=>$username,'email'=>$email];
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Sign Up</title>
<link rel="stylesheet" href="assets/style2.css">
</head>
<body class="centered">
       <!-- Logo Section -->
    <div class="logo-box">
        <img src="icons/X_logo_2023_(white).png" alt="Logo" class="logo">
    </div>
  <div class="card">

    <h2>Create account</h2>
    <?php if($errors): ?>
      <div class="errors"><?php foreach($errors as $e) echo "<div>$e</div>"; ?></div>
    <?php endif; ?>
    <form method="post">
      <input name="username" placeholder="Username" value="<?=htmlspecialchars($_POST['username'] ?? '')?>" required>
      <input name="email" placeholder="Email" value="<?=htmlspecialchars($_POST['email'] ?? '')?>" required>
      <input type="password" name="password" placeholder="Password" required>
      <input type="password" name="confirm_password" placeholder="Confirm Password" required>
      <button type="submit">Sign Up</button>
    </form>
    <div class="alt">
      Already have an account? <a href="index.php">Sign in</a>
    </div>
    <div class="google-block">
      <form action="google_login.php" method="post">
        <button type="submit" name="google" class="google-btn" style="color:black;">Sign up with Google</button>
      </form>
    </div>
  </div>
  <footer class="footer" style="bottom: -20px;">
  <div class="footer-links">
    <a href="#">Terms of Service</a>|
    <a href="#">Privacy Policy</a>|
    <a href="#">Cookies</a>|
    <a href="#">Accessibility</a>|
    <a href="#">Ads info</a>|
    <a href="#">More...</a>
  </div>
</footer>
<script src="assets/script.js"></script>
</body>
</html>
