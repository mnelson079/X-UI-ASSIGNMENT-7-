<?php
require 'db.php';
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($login === '' || $password === '') {
        $errors[] = 'Please fill all fields.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$login,$login]);
        $user = $stmt->fetch();
        if (!$user) {
            $errors[] = 'Account not found.';
        } elseif (!password_verify($password, $user['password'])) {
            $errors[] = 'Wrong password.';
        } else {
            $_SESSION['user'] = ['id'=>$user['id'],'username'=>$user['username'],'email'=>$user['email']];
            header('Location: dashboard.php');
            exit;
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Sign In</title>
    <link rel="stylesheet" href="assets/style2.css">
</head>

<body class="centered">

    <!-- Logo Section -->
    <div class="logo-box">
        <img src="icons/X_logo_2023_(white).png" alt="Logo" class="logo">
    </div>

    <!-- Sign In Card -->
    <div class="card">
        <h2>Sign In</h2>

        <?php if (!empty($errors)): ?>
            <div class="errors">
                <?php foreach ($errors as $e) echo "<div>$e</div>"; ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <input name="login" placeholder="Username or Email"
                   value="<?= htmlspecialchars($_POST['login'] ?? '') ?>" required>

            <input type="password" name="password" placeholder="Password" required>
          
            <button type="submit">Sign In</button>
        </form>

        <div class="alt">
          I don't have account
            <a href="signup.php">Create an account</a>
        </div>

        <div class="google-block">
            <form action="google_login.php" method="post">

                <button type="submit" name="google" class="google-btn" style="color: black;">
                    Login with Google
                </button>
            </form>
        </div>
    </div>
    <footer class="footer">
  <div class="footer-links">
    <a href="#">Terms of Service</a>|
    <a href="#">Privacy Policy</a>|
    <a href="#">Cookies</a>|
    <a href="#">Accessibility</a>|
    <a href="#">Ads info</a>|
    <a href="#">More...</a>
  </div>
</footer>

    <script src="assets/script.js"></script>
</body>
</html>
