<?php
require 'db.php';
if (!isset($_SESSION['user'])) { header('Location:index.php'); exit;}
$id = $_GET['id'] ?? null;
if (!$id) { header('Location:dashboard.php'); exit;}
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();
if (!$student) { header('Location:dashboard.php'); exit; }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    if ($student_id === '' || $name === '') $errors[] = 'Student ID and Name required.';
    if (!$errors) {
        $stmt = $pdo->prepare("UPDATE students SET student_id=?, name=?, email=? WHERE id=?");
        $stmt->execute([$student_id,$name,$email,$id]);
        header('Location:dashboard.php'); exit;
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Edit Student</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="centered">
  <div class="card">
    <h3>Edit Student</h3>
    <?php if($errors) foreach($errors as $e) echo "<div class='errors'>$e</div>"; ?>
    <form method="post">
      <input name="student_id" placeholder="Student ID" value="<?=htmlspecialchars($student['student_id'])?>" required>
      <input name="name" placeholder="Name" value="<?=htmlspecialchars($student['name'])?>" required>
      <input name="email" placeholder="Email" value="<?=htmlspecialchars($student['email'])?>">
      <div>
        <button type="submit">Update</button>
        <a href="dashboard.php" class="link">Cancel</a>
      </div>
    </form>
  </div>
</body>
</html>
